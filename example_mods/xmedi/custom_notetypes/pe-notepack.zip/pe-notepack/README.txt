1. go into the "mods" folder in your version of Psych Engine
2. once you have the folders copied, put it in the mods folder
3. if it asks you if you want to replace those files, click yes
4. there you go! they can now be used in the chart editor

also you need v0.5.1 of psych engine or higher to use this

p.s.: you can use the template to make your own kinds of custom notes

*ADDITIONAL CREDITS (also on the gamebanana page)*
Doki Doki Takeover Mod Team - Markov Note Graphics
Banbuds - EX + Fire Note Graphics
FNF: Flipped Out Mod Team - Camo Note Graphics
Me - everything else

I will update this soon